<?php 
	require "header.php";
?>

<main>

	<div class="container">
		
			<h2 class="center-text">Contactez nous !</h2>
		
			<form action="include/contact.inc.php" class="contact-form" method="post">
				<input type="text" name="name" placeholder="Nom et prénom...">
				<input type="text" name="email" placeholder="Email...">
				<input type="text" name="heading" placeholder="Objet...">
				<textarea name="message" cols="10" rows="10" placeholder="Votre message..."></textarea>
				<button type="submit" name="contact-submit">Envoyer</button>
			</form>

	</div>

</main>

<?php 
	require "footer.php";
?>