
<footer>
	<p>Nicolás Filizzola ©2020 Tous droits reservés</p>
	<p><a href='contact.php'>Contact</a> | <a href='legalmentions.php'>Mentions légales</a></p>
	<p></p>
	<img src="img/LOGO-nf.svg">
</footer>

	</body>
</html>
