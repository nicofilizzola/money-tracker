<?php 
	require "header.php";
?>

<main>
	
	<?php
	
		// WELCOME MESSAGES FOR NEW USERS
		if(isset($_GET['state'])){
			
			// IF DIRECTLY REDIRECTED AFTER SIGNUP
			if ($_GET['state'] == 'new'){
				echo 
					"<div class='container'>
						<p>Commençons par ajouter un compte. </p>
					</div>";
				
			// IF REDIRECTED FROM HOME
			} elseif ($_GET['state'] == 'new2'){
				echo 
					"<div class='container'>
						<p>Il faut toujours ajouter un premier compte. Allons y !</p>
					</div>";
			}
			
		}
	
	?>
	
	<div class="container">
		<h2>Ajouter nouveau compte</h2>
		<form action="include/newaccount.inc.php" method="post">
			
			<?php

			require('include/dbh.inc.php');
			
			if (isset($_GET['step'])){
				switch ($_GET['step']) {
						
					// FIRST STEP
					case 'country':
						echo
						"<p>Sélectionnez le pays de votre compte</p>
						<select name='country'>";

						// SQL ACTION: SELECT COUNTRIES AVAILABLE
						$sql = "SELECT DISTINCT country_accounts FROM accounts;";
						$result = mysqli_query($conn, $sql);
						$resultCheck = mysqli_num_rows($result);

						if ($resultCheck > 0){
							while ($row = mysqli_fetch_assoc($result)) {
								echo 
								// SHOW COUNTRY OPTIONS
								"<option value='".$row['country_accounts']."'>".$row['country_accounts']."</option>";
							}
						}

						echo 
									"</select><br><br>
								<button type='submit' name='country-submit'>Étape suivante</button>
							</form>";
						break;
						
					// SECOND STEP
					case 'account':
						echo
							"<p>Séléctionnez votre banque</p>
							<select name='account'>
						</form>";
						
						// SQL ACTION: SELECT ACCOUNTS AVAILABLE
						$sql = "SELECT name_accounts FROM accounts WHERE country_accounts = ?;";
						$stmt = mysqli_stmt_init($conn);
						
						// CHECK IF STATEMENT WORKS
						if (!mysqli_stmt_prepare($stmt, $sql)){
							header ("Location: newaccount.php?error=sql_stmt_select_account");
							exit();
							
						// EXECUTE SQL ACTION
						} else {
							mysqli_stmt_bind_param($stmt, "s", $_GET['country']);
							mysqli_stmt_execute($stmt);
						}
						$resultCheck = mysqli_stmt_get_result($stmt);
							while ($row = mysqli_fetch_assoc($resultCheck)) {
								
								// SHOW ACCOUNT OPTIONS
								echo 
									"<option value='".$row['name_accounts']."'>".$row['name_accounts']."</option>
								</form>";
							}
						
						echo 
									"</select><br><br>
								<button type='submit' name='account-submit'>Étape suivante</button>
							</form>";
						
						break;
						
					// PROBLEM STARTS HERE
					case 'insert':
						
						echo 
							"<p>Pour finir, il faut maintenant premier un nouveau mouvement. Cela peut être votre montant actuel.</p>
								<input type='number' name='amount' placeholder='Quantité...'>
								<input type='text' name='ref' placeholder='Référence...'>
								<input class='hidden' type='date' name='date' value=".date('Y-m-d').">
								<button type='submit' name='insert-submit'>Valider</button>
							</form>";
						
				}
				
			} else {
				
				header("Location: newaccount.php?step=country");
				
			}
			
			
			?>
			
		</form>
		
	</div>
	
</main>

<?php 
	require "footer.php";
?>