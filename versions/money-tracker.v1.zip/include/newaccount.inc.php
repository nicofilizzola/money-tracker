<?php

session_start();
require_once('dbh.inc.php');

// FIRST STEP
	if (isset($_POST['country-submit'])){
		$country = $_POST['country'];
		header('Location: ../newaccount.php?step=account&country='.$country);
		exit();
		
// SECOND STEP
	} elseif (isset($_POST['account-submit'])){
		$_SESSION['account-insert'] = $_POST['account'];
		header('Location: ../newaccount.php?step=insert&account='.$account);
		exit();
		
	} elseif (isset($_POST['insert-submit'])){
		$amount = $_POST['amount'];
		$ref = $_POST['ref'];
		$date = $_POST['date'];
		$account = $_SESSION['account-insert'];
		
		
		$sql = "SELECT id_accounts FROM accounts WHERE name_accounts = '$account'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		while ($row = mysqli_fetch_assoc($result)){
			$accountID = $row['id_accounts'];
		}
		
		$sql = "INSERT INTO moves (id_users, id_accounts, amount_moves, ref_moves, date_moves) VALUES (?, ?, ?, ?, ?)";
		$stmt = mysqli_stmt_init($conn);
						
		// CHECK IF STATEMENT WORKS
		if (!mysqli_stmt_prepare($stmt, $sql)){
			header ("Location: newaccount.php?error=sql_stmt_insert");
			exit();

		// EXECUTE SQL ACTION
		} else {
			mysqli_stmt_bind_param($stmt, "iiiss", $_SESSION['id_users'], $accountID, $amount, $ref, $date);
			mysqli_stmt_execute($stmt);
			
			header ("Location: ../index.php?new=account");
		}
}
// NEW ACCOUNT PROBLEM : REDIRECTS TO FIRST STEP AFTER COMPLETING