CREATE TABLE users (
	id_users INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
	email_users TINYTEXT NOT NULL,
	uid_users TINYTEXT NOT NULL,
	pwd_users LONGTEXT NOT NULL,
);

CREATE TABLE accounts (
	id_accounts INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
	name_accounts TINYTEXT NOT NULL,
	country_accounts TINYTEXT NOT NULL,
	currency_accounts TINYTEXT NOT NULL
);

CREATE TABLE moves (
	id_moves INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
	id_users INT(11) NOT NULL,
	FOREIGN KEY (id_users) REFERENCES users(id_users),
	id_accounts INT(11) NOT NULL,
	FOREIGN KEY (id_account) REFERENCES accounts(id_accounts),
	amount_moves INT(255) NOT NULL,
	ref_moves TINYTEXT,
	date_moves DATE NOT NULL
);

INSERT INTO accounts(name_accounts, country_accounts, currency_accounts) VALUES ("Société Générale","France","€");
INSERT INTO accounts(name_accounts, country_accounts, currency_accounts) VALUES ("HSBC France","France","€");
INSERT INTO accounts(name_accounts, country_accounts, currency_accounts) VALUES ("LCL Banque et assurance","France","€");
INSERT INTO accounts(name_accounts, country_accounts, currency_accounts) VALUES ("BNP Paribas","France","€");
INSERT INTO accounts(name_accounts, country_accounts, currency_accounts) VALUES ("Banque Populaire","France","€");
INSERT INTO accounts(name_accounts, country_accounts, currency_accounts) VALUES ("Crédit Agricole","France","€");
INSERT INTO accounts(name_accounts, country_accounts, currency_accounts) VALUES ("Caisse d'Épargne","France","€");
INSERT INTO accounts(name_accounts, country_accounts, currency_accounts) VALUES ("La Banque Postale","France","€");
INSERT INTO accounts(name_accounts, country_accounts, currency_accounts) VALUES ("Crédit Mutuel (CIC)","France","€");


SELECT name_accounts FROM accounts, moves WHERE moves.id_moves = (SELECT MAX(id_moves) FROM moves) AND moves.id_accounts = accounts.id_accounts AND moves.id_users = 3
/* SELECCIONAR ULTIMA MOVE */

